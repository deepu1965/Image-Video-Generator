const gallery = document.getElementById('gallery');
const imageList = document.getElementById('image-list');
const selected = document.getElementById('selected');

function handleFiles(files) {    
    for (const file of files) {
        function onButtonClick() {
            selected.appendChild(img)
        }
    
        if (!file.type.startsWith('image/')) continue;

        const img = document.createElement('img');
        img.src = URL.createObjectURL(file);
        gallery.appendChild(img);
        img.addEventListener('click', onButtonClick);
    }
}

const dropArea = document.getElementById('drop-area');

['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, preventDefaults, false);
});

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

['dragenter', 'dragover'].forEach(eventName => {
    dropArea.addEventListener(eventName, highlight, false);
});

['dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, unhighlight, false);
});

function highlight(e) {
    dropArea.classList.add('highlight');
}

function unhighlight(e) {
    dropArea.classList.remove('highlight');
}

dropArea.addEventListener('drop', handleDrop, false);

function handleDrop(e) {
    const dt = e.dataTransfer;
    const files = dt.files;
    handleFiles(files);
}

 function playAudio() {
    var audioSelect = document.getElementById("audioSelect");
    var audioPlayer = document.getElementById("audioPlayer");
    var selectedAudio = audioSelect.value;

    audioPlayer.src = selectedAudio;
    audioPlayer.play();
}


const selectedImages = document.querySelectorAll('#selected img');

function setResolution() {
    var resolutionSelect = document.getElementById("resolution_select");
    var selectedResolution = resolutionSelect.value;
    var selectedDiv = document.querySelectorAll("#selected img");
    for(var file of selectedDiv) {
        file.style.width = selectedResolution.split(" ")[0];
        file.style.height = selectedResolution.split(" ")[1];
    }
}

// var i = 0;
// const show_area = document.getElementById('slideshow');
// function slideshow() {
//     for(file in selectedImages){
//         show_area.appendChild(file);
//     }
// }   